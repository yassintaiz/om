  // تحميل التقييمات من localStorage عند فتح الصفحة
  document.addEventListener("DOMContentLoaded", loadReviews);

  function addReview() {
      const name = document.getElementById("name").value.trim();
      const rating = document.getElementById("rating").value;
      const comment = document.getElementById("comment").value.trim();

      if (!name || !rating || rating < 1 || rating > 5) {
          alert("يرجى إدخال اسم وتقييم صحيح بين 1 و 5");
          return;
      }

      const review = { name, rating, comment };
      let reviews = JSON.parse(localStorage.getItem("reviews")) || [];
      reviews.push(review);
      localStorage.setItem("reviews", JSON.stringify(reviews));

      loadReviews();
      document.getElementById("name").value = "";
      document.getElementById("rating").value = "";
      document.getElementById("comment").value = "";
  }

  function loadReviews() {
      const reviewsContainer = document.getElementById("reviews");
      reviewsContainer.innerHTML = "";

      let reviews = JSON.parse(localStorage.getItem("reviews")) || [];

      reviews.forEach((review, index) => {
          const reviewDiv = document.createElement("div");
          reviewDiv.classList.add("review");

          reviewDiv.innerHTML = `
              <strong>${review.name}</strong>
              <div class="stars">${"⭐".repeat(review.rating)}</div>
              <p>${review.comment}</p>
          `;
          reviewsContainer.appendChild(reviewDiv);
      });
  }

  function clearReviews() {
      localStorage.removeItem("reviews");
      loadReviews();
  }